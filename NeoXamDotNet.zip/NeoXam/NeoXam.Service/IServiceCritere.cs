﻿using NeoXam.Domain.Entities;
using NeoXam.ServicePattern;

namespace NeoXam.Service
{
    public interface IServiceCritere:IService<critere>
    {

    }
}
