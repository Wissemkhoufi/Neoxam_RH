﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NeoXam.Service;
using NeoXam.Domain.Entities;
using NeoXam.ServicePattern;

namespace NeoXam.Service
{
    interface ICongeservice : IService<conge>
    {
    }
}
