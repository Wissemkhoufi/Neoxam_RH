﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NeoXam.Web.Models
{
    public class TypeAlgo
    {
    }

    public enum Gender
    {
        Single,
        Complete,
        UPGMA,
        WPGMA,
        UPGMC,
        WPGMC,
        Ward
    }
}