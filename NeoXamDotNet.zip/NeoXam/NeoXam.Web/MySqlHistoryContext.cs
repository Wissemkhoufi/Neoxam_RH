﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.Entity;
using System.Data.Entity.Migrations.History;
using System.Linq;
using System.Web;

namespace NeoXam.Web
{

    public class MySqlHistoryContext
    {
       
    }
}